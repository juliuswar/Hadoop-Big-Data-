#!/usr/bin/python

import sys

# input comes from STDIN (standard input)

for line in sorted(sys.stdin): #sysstdin hanya objek file lain yang gunanya membaca file 
    line = line.strip() #menghapus spasi pada string
    line = line.split(",") #memecah kata pertama dan kedua dengan ,

    if len(line) >=1: #jika kolom lebih dari 1 atau sama dengan 1 
        FlightNum = line[0] #kolom 0 = flight number
        CRSElapsedTime = line[1] #kolom 1 = estimasi keterlambatan
	
        print '%s\t%s' % (FlightNum, CRSElapsedTime)

