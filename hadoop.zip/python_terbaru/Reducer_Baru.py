#!/usr/bin/python
#Reducer.py
import sys


flight_number = {}

#Partitoner
for line in sorted(sys.stdin): #membuka file 
    line = line.strip() 
    FlightNum, CRSElapsedTime = line.split('\t') #memecah per kata1 dan kata2  

    if FlightNum in flight_number:
        flight_number[FlightNum].append(int(CRSElapsedTime)) 
    else:
        flight_number[FlightNum] = []  
        flight_number[FlightNum].append(int(CRSElapsedTime))  

#Reducer
for FlightNum in sorted(flight_number.keys()): 
    ave_CRSElapsedTime = sum(flight_number[FlightNum])*1.0 / len(flight_number[FlightNum]) 
	
    print '%s\t%s'% (FlightNum, ave_CRSElapsedTime)
